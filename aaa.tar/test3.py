print('hello user')
x = int(input())
for i in range(x):
    print('*'*i)


