print('Hi Guys')
